#by name, display dates talked to
#display gift ideas
#display birthday
#display location
#display all interactions
#display all interactions within past year
#by day, plot daily feelings

